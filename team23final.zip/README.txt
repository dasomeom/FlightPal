1. Description - FlightPal web application which aims to bridge the gap in data based travel planning tools.
2. Installation - 
	2.1. Install Node.js using the msi located in /CODE/FlightPal/dataset (for windows) or download and install Node.js from here: https://nodejs.org/en/download/
   	     * During installation, select the radio button titled "Automatically install the necessary tools."
	2.2. Install sqlite3 for node.js. Open a command window with admin privilages from within /CODE/FlightPal/dataset folder and type: npm install sqlite3 
		* This installs sqlite3 library for node.js.
		* On linux or mac, you may need to type sudo prior to the npm command (for example: sudo npm install sqlite3).
	2.3. Install express.js for node.js. Open a command window with admin privilages from within /CODE/FlightPal/dataset folder and type: npm install express
	2.4. Install body-parser for node.js pen a command window with admin privilages from within /CODE/FlightPal/dataset folder and type: npm install body-parser

3. Execution - 
	3.1 To run the backend REST server go to the /Code/FlightPal/dataset folder using a command line with admin privilages and type: 
		* On windows type: node .\flightpal_rest.js 
		* On linux or mac type: node flightpal_rest.js . 
		* This starts the REST API server which can then be queried using a client. You should see a: "Listning on port 8000" on successful execution.
		* Because this is a server application, it does not exit or finish until stopped manually (using Ctrl-C) 

	3.2 To run the client application, use your prefered http server from within the /CODE/FlightPal. For example
		* Using python 2.x: python -m SimpleHTTPServer 5500
		* Using visual studo code with html module: right click on index.html and select "Open with live server".
		* The backend server uses port 8000 which should be avoided on the client.
		* The backend server MUST be started prior to loading the client on a browser.